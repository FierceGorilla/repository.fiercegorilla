import xbmcaddon
import base64

MainBase = base64.b64decode ('aHR0cDovL215YXRvbS5vbmUvYWRkb24vaG9tZS54bWw=')
addon = xbmcaddon.Addon('plugin.video.ATOMREBORN')